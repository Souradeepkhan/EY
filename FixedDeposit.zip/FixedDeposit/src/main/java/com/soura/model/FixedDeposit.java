package com.soura.model;

import java.time.LocalDate;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="FixedDeposits")
public class FixedDeposit {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long fd_id;
	
	@Column(name="CustomerID")
	private Long customerId;
	
	@Column(name="AccountID")
	private Long accountId;
	
	@Column(name="DepositAmount")
	private double depositAmount;
	
	@Column(name="deposit_period")
	private Integer DepositPeriod;
	
	@Column(name="StartDate")
	private LocalDate startDate;
	
	
	@Column(name="MaturityDate")
	private LocalDate maturityDate;

	
}
