package com.soura.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soura.dto.FixedDepositDTO;
import com.soura.model.FixedDeposit;
import com.soura.repository.FixedDepositRepository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FixedDepositService {
    @Autowired
    private FixedDepositRepository fixedDepositRepository;

    @Autowired
    private ModelMapper modelMapper;
    

    public List<FixedDepositDTO> getAllFixedDeposits() {
    	
    	List<FixedDepositDTO> fixedDepositDTOs = new ArrayList<>();
    	fixedDepositRepository.findAll().forEach(fd->{
    		fixedDepositDTOs.add(modelMapper.map(fd,FixedDepositDTO.class));
    	});
    	
    	return fixedDepositDTOs;
    	
    }

    public FixedDepositDTO createFixedDeposit(FixedDepositDTO fixedDepositDTO) {
    	
    	fixedDepositDTO.setStartDate(LocalDate.now());
    	fixedDepositDTO.setMaturityDate(fixedDepositDTO.getStartDate().plusMonths(fixedDepositDTO.getDepositPeriod()));
    	
        FixedDeposit fixedDeposit = modelMapper.map(fixedDepositDTO, FixedDeposit.class);
        FixedDeposit saveFixedDeposit = fixedDepositRepository.save(fixedDeposit);
        return modelMapper.map(saveFixedDeposit, FixedDepositDTO.class);
    }
    
}