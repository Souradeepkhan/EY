package com.soura.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soura.dto.FixedDepositDTO;
import com.soura.service.FixedDepositService;

@RestController
@CrossOrigin
@RequestMapping("/fixeddeposits")
public class FixedDepositController {
    @Autowired
    private FixedDepositService fixedDepositService;

    @GetMapping
    public List<FixedDepositDTO> getAllFixedDeposits() {
        return fixedDepositService.getAllFixedDeposits();
    }

    @PostMapping
    public FixedDepositDTO createFixedDeposit(@RequestBody FixedDepositDTO fixedDepositDTO) {
        return fixedDepositService.createFixedDeposit(fixedDepositDTO);
    }
    
}