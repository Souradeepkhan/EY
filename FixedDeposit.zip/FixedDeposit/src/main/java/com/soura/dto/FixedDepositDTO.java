package com.soura.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class FixedDepositDTO {
	private Long customerId;
	private Long accountId;
	private Double depositAmount;
	private Integer depositPeriod;
	private LocalDate startDate;
	private LocalDate maturityDate;
	
}
