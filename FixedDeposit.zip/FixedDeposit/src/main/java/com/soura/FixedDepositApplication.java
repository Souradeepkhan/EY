package com.soura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FixedDepositApplication {

	public static void main(String[] args) {
		SpringApplication.run(FixedDepositApplication.class, args);
	}

}
