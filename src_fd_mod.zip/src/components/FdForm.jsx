import React, { useState, useEffect } from 'react';

function FdForm() { const [fd, setFd] = useState({ customerId: '', accountId: '', depositAmount: '', depositPeriod: '', startDate: '', maturityDate: '' });

useEffect(() => {
    const currentDate = new Date().toISOString().split('T')[0];
    setFd(prevFd => ({
        ...prevFd,
        startDate: currentDate,
        maturityDate: prevFd.depositPeriod ? calculateMaturityDate(currentDate, prevFd.depositPeriod) : ''
    }));
}, []);

const handleChange = (e) => {
    const { name, value } = e.target;
    setFd(prevFd => ({
        ...prevFd,
        [name]: value,
        maturityDate: (name === 'startDate' && prevFd.depositPeriod) || (name === 'depositPeriod' && prevFd.startDate)
            ? calculateMaturityDate(name === 'startDate' ? value : prevFd.startDate, name === 'depositPeriod' ? value : prevFd.depositPeriod)
            : ''
    }));
};

const calculateMaturityDate = (startDate, period) => {
    const startDateObj = new Date(startDate);
    const maturityDateObj = new Date(startDateObj.setMonth(startDateObj.getMonth() + parseInt(period)));
    return maturityDateObj.toISOString().split('T')[0];
};

const handleSubmit = (e) => {
    e.preventDefault();
    fetch('http://172.19.62.151:2020/fixeddeposits', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(fd)
    })
    .then(response => {
        if (response.ok) {
            return response.json();
        }
        throw new Error('Error creating Fixed Deposit');
    })
    .then(data => {
        alert('Fixed Deposit created successfully');
        setFd({
            customerId: '',
            accountId: '',
            depositAmount: '',
            depositPeriod: '',
            startDate: '',
            maturityDate: ''
        });
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error creating Fixed Deposit');
    });
};
const formStyle = {
        maxWidth: '500px',
        margin: '0 auto',
        width:'100%',
        align:'center',
        padding: '20px',
        border: '1px solid #ccc',
        borderRadius: '10px',
        backgroundColor: '#f9f9f9',
        position:'absolute',
        left:'30%'
        
    };
    
    const inputStyle = {
        display: 'block',
        width: '90%',
        padding: '10px',
        margin: '10px 10px',
        borderRadius: '5px',
        border: '1px solid #ccc'
    };
    
    const labelStyle = {
        margin: '10px 0 5px',
        fontWeight: 'bold'
    };
    
    const buttonStyle = {
        width: '100%',
        padding: '10px',
        borderRadius: '5px',
        border: 'none',
        backgroundColor: '#28a745',
        color: 'white',
        fontSize: '16px',
        cursor: 'pointer'
    };

return (
    <form onSubmit={handleSubmit} style={formStyle}>
        <div>
            <h1>Add Fixed Deposit </h1>
        </div>
        <div>
            <label style={labelStyle}>Customer ID:</label>
            <input type="text" name="customerId" value={fd.customerId} onChange={handleChange} style={inputStyle} required />
        </div>
        <div>
            <label style={labelStyle}>Account ID:</label>
            <input type="text" name="accountId" value={fd.accountId} onChange={handleChange} style={inputStyle} required />
        </div>
        <div>
            <label style={labelStyle}>Deposit Amount:</label>
            <input type="number" name="depositAmount" value={fd.depositAmount} onChange={handleChange} style={inputStyle} required />
        </div>
        <div>
            <label style={labelStyle}>Deposit Period (months):</label>
            <input type="number" name="depositPeriod" value={fd.depositPeriod} onChange={handleChange} style={inputStyle} required />
        </div>
        <div>
            <label style={labelStyle}>Start Date:</label>
            <input type="date" name="startDate" value={fd.startDate} onChange={handleChange} style={inputStyle} required />
        </div>
        <div>
            <label style={labelStyle}>Maturity Date:</label>
            <input type="date" name="maturityDate" value={fd.maturityDate} readOnly style={inputStyle} required />
        </div>
        <button type="submit" style={buttonStyle}>Create Fixed Deposit</button>
    </form>
);
}

export default FdForm;