import React from 'react'; 

import FdForm from './components/FdForm';

function App() { 
  
  return (
    <div className='App'>
      {/* <h1>Fixed Deposit Form</h1> */}
      <FdForm/>
    </div>
  );
  }
  
  export default App;