package com.rk.StudentApp.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDescriptionVO {

	private Integer id;
	private String brand;
	private String model;
	private Long price;
}
