package com.rk.StudentApp.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rk.StudentApp.entity.ProductEntity;
import com.rk.StudentApp.service.ProductService;

@RestController
@RequestMapping("description")
public class ProductController {

	@Autowired
	private ProductService productService;

	@GetMapping("/getall")
	public List<ProductEntity> getAll() {
		return productService.getAll();
	}
	@PostMapping("/savedescription")
	public ProductEntity addDescription(@RequestBody ProductEntity entity) {
		return productService.addDescription(entity);
		
	}
	@GetMapping("/getbyid/{id}")
	public Optional<ProductEntity> getbyId(@PathVariable("id") Integer id) {
		return productService.getbyId(id);
	}
}
