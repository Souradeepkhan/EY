package com.rk.StudentApp.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.rk.StudentApp.entity.ProductEntity;

@Service
public class ProductService {

	@Autowired
	private ProductRepository repository;

	public Optional<ProductEntity> getbyId(Integer id) {
		return repository.findById(id);
	}

	public ProductEntity addDescription(ProductEntity entity) {
		return repository.save(entity);
	}

	public List<ProductEntity> getAll() {
		return repository.findAll();
	}
}
