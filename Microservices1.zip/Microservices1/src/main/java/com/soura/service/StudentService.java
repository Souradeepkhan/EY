package com.soura.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.soura.entity.Student;
import com.soura.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	private StudentRepository studentRepository;
	
	public Student getStudentById(Integer id) {
		return studentRepository.findById(id).orElseThrow(()-> new RuntimeException("Student not found with id :"+id));
	}
	
//	public List<Student> getStudentsByLname(String lname){
//		return studentRepository.findByLname(lname);
//	}
	
	public Student createStudent(Student student) {
		return studentRepository.save(student);
	}
}