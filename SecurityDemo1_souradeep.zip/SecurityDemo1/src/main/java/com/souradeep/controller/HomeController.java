package com.souradeep.controller;

import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HomeController {
	
	
	@GetMapping("auth/welcome")
	public String home() {
		return "<h1>Home Page</h1>";
	}
	
	@GetMapping("auth/admin")
	//@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String admin() {
		return "<h1>Admin Page</h1>";
	}
	@GetMapping("auth/admin/two")
	//@Secured("ROLE_ADMIN")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	public String admin2() {
		return "<h1>Admin 2 Page</h1>";
	}
	
	@GetMapping("auth/user")
	//@Secured("ROLE_USER")
	@PreAuthorize("hasAuthority('ROLE_USER')")
	public String user() {
		return "<h1>Home User Page</h1>";
	}
}
